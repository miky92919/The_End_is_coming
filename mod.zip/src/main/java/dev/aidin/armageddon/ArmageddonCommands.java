package dev.aidin.armageddon;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public final class ArmageddonCommands {
    private ArmageddonCommands() {}

    public static void register(CommandDispatcher<ServerCommandSource> dispatcher) {
        dispatcher.register(CommandManager.literal("armageddon")
                .executes(c -> status(c.getSource()))
                .then(CommandManager.literal("status").executes(c -> status(c.getSource())))
                .then(CommandManager.literal("day")
                        .then(CommandManager.argument("day", IntegerArgumentType.integer(1))
                                .executes(c -> setDay(c.getSource(), IntegerArgumentType.getInteger(c, "day")))))
                .then(CommandManager.literal("in")
                        .then(CommandManager.argument("days", IntegerArgumentType.integer(0))
                                .executes(c -> setIn(c.getSource(), IntegerArgumentType.getInteger(c, "days")))))
                .then(CommandManager.literal("off").executes(c -> setEnabled(c.getSource(), false)))
                .then(CommandManager.literal("on").executes(c -> setEnabled(c.getSource(), true)))
                .then(CommandManager.literal("start").executes(c -> start(c.getSource())))
                .then(CommandManager.literal("reset").executes(c -> reset(c.getSource()))));
    }

    private static void msg(ServerCommandSource src, String text) {
        src.sendFeedback(() -> Text.literal(text), false);
    }

    private static long today(MinecraftServer server) {
        return server.getOverworld().getTime() / 24000L;
    }

    private static int status(ServerCommandSource src) {
        ArmageddonState s = ArmageddonMod.state;
        long day = today(src.getServer());
        String text;
        if (s.defeated) text = "The Armageddon Dragon was defeated.";
        else if (s.triggered) text = "Armageddon is happening right now!";
        else if (!s.enabled) text = "Armageddon is OFF. (Trigger day was " + s.triggerDay + ")";
        else text = "Day " + day + ". Armageddon starts on day " + s.triggerDay + " (" + Math.max(0, s.triggerDay - day) + " days left).";
        msg(src, text);
        return 1;
    }

    private static int setDay(ServerCommandSource src, int day) {
        ArmageddonMod.state.triggerDay = day;
        ArmageddonMod.state.save(src.getServer());
        msg(src, "Armageddon will start on day " + day + ".");
        return 1;
    }

    private static int setIn(ServerCommandSource src, int days) {
        long target = today(src.getServer()) + days;
        ArmageddonMod.state.triggerDay = (int) target;
        ArmageddonMod.state.save(src.getServer());
        msg(src, "Armageddon will start in " + days + " days (day " + target + ").");
        return 1;
    }

    private static int setEnabled(ServerCommandSource src, boolean on) {
        ArmageddonMod.state.enabled = on;
        ArmageddonMod.state.save(src.getServer());
        msg(src, on ? "Armageddon is ON." : "Armageddon is OFF.");
        return 1;
    }

    private static int start(ServerCommandSource src) {
        if (ArmageddonMod.state.triggered && !ArmageddonMod.state.defeated) {
            msg(src, "Armageddon is already happening.");
            return 0;
        }
        if (!ArmageddonMod.start(src.getServer())) {
            msg(src, "Nobody is in the Overworld.");
            return 0;
        }
        return 1;
    }

    private static int reset(ServerCommandSource src) {
        ArmageddonMod.state.triggered = false;
        ArmageddonMod.state.defeated = false;
        ArmageddonMod.state.save(src.getServer());
        msg(src, "Armageddon was reset. Set a new day with /armageddon day <n> or /armageddon in <n>.");
        return 1;
    }
}
