package dev.aidin.armageddon;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.TypeFilter;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

public class ArmageddonMod implements ModInitializer {
    public static final String MOD_ID = "armageddon";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static ArmageddonState state = new ArmageddonState();
    private static int tickCounter = 0;
    private static long lastDay = -1;

    @Override
    public void onInitialize() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            state = ArmageddonState.load(server);
            lastDay = -1;
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            state.save(server);
            DragonDriver.clear();
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                ArmageddonCommands.register(dispatcher));

        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof EnderDragonEntity dragon && world.getRegistryKey() != World.END) {
                DragonDriver.register(dragon, world);
            }
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (entity instanceof EnderDragonEntity dragon) {
                DragonDriver.unregister(dragon);
            }
        });

        ServerLivingEntityEvents.ALLOW_DAMAGE.register(DragonDriver::allowDamage);
        ServerTickEvents.END_SERVER_TICK.register(ArmageddonMod::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        DragonDriver.tick();
        if (++tickCounter % 20 != 0) return;

        if (state.triggered) {
            purgeEndDragons(server);
            return;
        }
        if (!state.enabled) return;

        ServerWorld overworld = server.getOverworld();
        long day = overworld.getTime() / 24000L;
        long remaining = state.triggerDay - day;

        if (day != lastDay) {
            lastDay = day;
            if (remaining == 10 || remaining == 3 || remaining == 1) {
                server.getPlayerManager().broadcast(Text.literal("The sky grows dark... Armageddon arrives in "
                        + remaining + (remaining == 1 ? " day." : " days.")).formatted(Formatting.RED), false);
            }
        }
        if (remaining <= 0) {
            start(server);
        }
    }

    /** Starts the event. Returns false if nobody is in the Overworld yet. */
    public static boolean start(MinecraftServer server) {
        ServerWorld overworld = server.getOverworld();
        List<ServerPlayerEntity> players = overworld.getPlayers();
        if (players.isEmpty()) return false;

        ServerPlayerEntity target = players.get(overworld.getRandom().nextInt(players.size()));
        state.triggered = true;
        state.defeated = false;
        state.save(server);

        purgeEndDragons(server);
        DragonDriver.spawnDragon(overworld, target);

        server.getPlayerManager().broadcast(Text.literal(
                "ARMAGEDDON! The Ender Dragon has left the End and descended upon the Overworld!")
                .formatted(Formatting.DARK_RED, Formatting.BOLD), false);
        return true;
    }

    private static void purgeEndDragons(MinecraftServer server) {
        ServerWorld end = server.getWorld(World.END);
        if (end == null) return;
        for (EnderDragonEntity d : end.getEntitiesByType(TypeFilter.instanceOf(EnderDragonEntity.class), e -> true)) {
            d.discard();
        }
    }
}
