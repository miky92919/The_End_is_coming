package dev.aidin.armageddon;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.nio.file.Files;
import java.nio.file.Path;

public class ArmageddonState {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public boolean enabled = true;
    public int triggerDay = 100;
    public boolean triggered = false;
    public boolean defeated = false;

    private static Path file(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("armageddon.json");
    }

    public static ArmageddonState load(MinecraftServer server) {
        try {
            Path p = file(server);
            if (Files.exists(p)) {
                ArmageddonState s = GSON.fromJson(Files.readString(p), ArmageddonState.class);
                if (s != null) return s;
            }
        } catch (Exception e) {
            ArmageddonMod.LOGGER.warn("Could not read armageddon.json, using defaults", e);
        }
        return new ArmageddonState();
    }

    public void save(MinecraftServer server) {
        try {
            Files.writeString(file(server), GSON.toJson(this));
        } catch (Exception e) {
            ArmageddonMod.LOGGER.warn("Could not save armageddon.json", e);
        }
    }
}
