package dev.aidin.armageddon;

import net.minecraft.advancement.AdvancementEntry;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.boss.dragon.EnderDragonEntity;
import net.minecraft.entity.boss.dragon.phase.ChargingPlayerPhase;
import net.minecraft.entity.boss.dragon.phase.Phase;
import net.minecraft.entity.boss.dragon.phase.PhaseManager;
import net.minecraft.entity.boss.dragon.phase.PhaseType;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.DragonFireballEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.Heightmap;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Drives every dragon that lives outside the End: flight pattern, fireballs,
 * army waves, boss bar, pylon shield and the death reward.
 * Flight itself is vanilla (the "charging" phase) - we only choose where it flies.
 */
public final class DragonDriver {
    public static final String PYLON_TAG = "armageddon_pylon";
    public static final String MINION_TAG = "armageddon_minion";

    private static final double DRAGON_HEALTH = 600.0;

    private static final List<EntityType<? extends MobEntity>> POOL_1 =
            List.of(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER);
    private static final List<EntityType<? extends MobEntity>> POOL_2 =
            List.of(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.SPIDER,
                    EntityType.CREEPER, EntityType.WITCH, EntityType.PILLAGER);
    private static final List<EntityType<? extends MobEntity>> POOL_3 =
            List.of(EntityType.ZOMBIE, EntityType.SKELETON, EntityType.CREEPER, EntityType.WITCH,
                    EntityType.PILLAGER, EntityType.VINDICATOR, EntityType.PHANTOM, EntityType.PHANTOM);

    static final class Brain {
        EnderDragonEntity dragon;
        ServerWorld world;
        final ServerBossBar bar = new ServerBossBar(Text.literal("Armageddon Dragon"),
                BossBar.Color.PURPLE, BossBar.Style.PROGRESS);
        boolean attacking = true;
        boolean defeated = false;
        int modeTicks = 0;
        double rx, ry, rz;
        double ax, az;
        int fireCooldown = 80;
        int waveCooldown = 100;
        int pylonCount = 0;
        int phase = -1;
        int hintCooldown = 0;
    }

    private static final Map<UUID, Brain> BRAINS = new ConcurrentHashMap<>();

    private DragonDriver() {}

    public static void clear() {
        for (Brain b : BRAINS.values()) b.bar.clearPlayers();
        BRAINS.clear();
    }

    // ------------------------------------------------------------------ lifecycle

    public static void register(EnderDragonEntity dragon, ServerWorld world) {
        Brain b = BRAINS.computeIfAbsent(dragon.getUuid(), id -> new Brain());
        if (b.world == null) {
            b.ax = dragon.getX();
            b.az = dragon.getZ();
            b.phase = phaseFor(dragon);
        }
        b.dragon = dragon;
        b.world = world;
    }

    public static void unregister(EnderDragonEntity dragon) {
        Brain b = BRAINS.get(dragon.getUuid());
        if (b != null) {
            b.dragon = null;
            b.bar.clearPlayers();
            if (dragon.isRemoved() && b.defeated) BRAINS.remove(dragon.getUuid());
        }
    }

    public static void spawnDragon(ServerWorld w, ServerPlayerEntity player) {
        EnderDragonEntity d = EntityType.ENDER_DRAGON.create(w, SpawnReason.EVENT);
        if (d == null) return;

        double ang = w.getRandom().nextDouble() * Math.PI * 2;
        double dist = 48;
        double x = player.getX() + Math.cos(ang) * dist;
        double z = player.getZ() + Math.sin(ang) * dist;
        if (!w.getChunkManager().isChunkLoaded(((int) Math.floor(x)) >> 4, ((int) Math.floor(z)) >> 4)) {
            dist = 32;
            x = player.getX() + Math.cos(ang) * dist;
            z = player.getZ() + Math.sin(ang) * dist;
        }
        // always well above the terrain at the spawn point, and high above the player
        double ground = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(x), (int) Math.floor(z));
        double y = Math.min(Math.max(player.getY() + 40, ground + 30), 300);
        d.setPosition(x, y, z);
        d.setYaw((float) Math.toDegrees(ang) + 90f);

        EntityAttributeInstance hp = d.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (hp != null) hp.setBaseValue(DRAGON_HEALTH);
        d.setHealth((float) DRAGON_HEALTH);

        w.spawnEntity(d);
        register(d, w);

        Brain b = BRAINS.get(d.getUuid());
        b.phase = 1;
        spawnPylons(w, player.getX(), player.getZ(), 4);
        b.pylonCount = 4;
    }

    // ------------------------------------------------------------------ per tick

    public static void tick() {
        if (BRAINS.isEmpty()) return;
        for (Brain b : List.copyOf(BRAINS.values())) {
            EnderDragonEntity d = b.dragon;
            if (d == null || b.defeated || b.world == null) continue;
            if (d.isRemoved() || d.isDead()) continue;
            tickDragon(b, d);
        }
    }

    private static void tickDragon(Brain b, EnderDragonEntity d) {
        ServerWorld w = b.world;
        Random r = w.getRandom();

        if (d.age % 10 == 0) b.pylonCount = countPylons(w, d);

        int ph = phaseFor(d);
        if (ph > b.phase) {
            b.phase = ph;
            onPhaseChange(b, d);
        }

        updateBar(b, d);

        PlayerEntity t = w.getClosestPlayer(d.getX(), d.getY(), d.getZ(), 160.0, true);
        if (t == null) {
            double a = d.age * 0.015;
            steer(d, b.ax + Math.cos(a) * 45, d.getY(), b.az + Math.sin(a) * 45);
            return;
        }

        b.modeTicks++;
        double dx = t.getX() - d.getX();
        double dy = t.getEyeY() - d.getY();
        double dz = t.getZ() - d.getZ();
        double dist = Math.sqrt(dx * dx + dy * dy + dz * dz);

        if (b.attacking) {
            // fly through the player and a bit beyond, so it never stalls on the target
            double len = Math.max(dist, 1.0);
            double ay = Math.max(t.getEyeY() + dy / len * 18.0, t.getY() + 1.0);
            steer(d, t.getX() + dx / len * 18.0, ay, t.getZ() + dz / len * 18.0);
            if (dist < 14.0 || b.modeTicks > 240) {
                double a = r.nextDouble() * Math.PI * 2;
                b.rx = t.getX() + Math.cos(a) * 60;
                b.rz = t.getZ() + Math.sin(a) * 60;
                b.ry = t.getY() + 25 + r.nextDouble() * 20;
                b.attacking = false;
                b.modeTicks = 0;
            }
        } else {
            steer(d, b.rx, b.ry, b.rz);
            double rdx = b.rx - d.getX();
            double rdy = b.ry - d.getY();
            double rdz = b.rz - d.getZ();
            if (rdx * rdx + rdy * rdy + rdz * rdz < 256 || b.modeTicks > 160) {
                b.attacking = true;
                b.modeTicks = 0;
            }
            if (--b.fireCooldown <= 0 && dist < 110) {
                shoot(w, d, t);
                b.fireCooldown = (b.phase == 1 ? 70 : b.phase == 2 ? 50 : 32) + r.nextInt(20);
            }
        }

        if (--b.waveCooldown <= 0) {
            spawnWave(b, t);
            b.waveCooldown = b.phase == 1 ? 900 : b.phase == 2 ? 700 : 500;
        }
    }

    private static int phaseFor(EnderDragonEntity d) {
        float f = d.getHealth() / d.getMaxHealth();
        return f > 0.66f ? 1 : f > 0.33f ? 2 : 3;
    }

    private static void onPhaseChange(Brain b, EnderDragonEntity d) {
        ServerWorld w = b.world;
        PlayerEntity t = w.getClosestPlayer(d.getX(), d.getY(), d.getZ(), 200.0, true);
        double cx = t != null ? t.getX() : d.getX();
        double cz = t != null ? t.getZ() : d.getZ();
        int n = b.phase == 2 ? 6 : 8;
        spawnPylons(w, cx, cz, n);
        b.pylonCount += n;
        b.fireCooldown = 20;
        broadcast(w, b.phase == 2
                ? "The dragon is wounded and furious! New pylons shield it again."
                : "The dragon enters its final rage! Destroy the pylons!");
    }

    // ------------------------------------------------------------------ movement

    /** Uses vanilla's charging phase as a "fly to this point" command. */
    private static void steer(EnderDragonEntity d, double x, double y, double z) {
        double dx = x - d.getX();
        double dy = y - d.getY();
        double dz = z - d.getZ();
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len > 120.0) {
            double k = 120.0 / len;
            x = d.getX() + dx * k;
            y = d.getY() + dy * k;
            z = d.getZ() + dz * k;
        }
        PhaseManager pm = d.getPhaseManager();
        if (pm.getCurrent().getType() != PhaseType.CHARGING_PLAYER) {
            pm.setPhase(PhaseType.CHARGING_PLAYER);
        }
        Phase cur = pm.getCurrent();
        if (cur instanceof ChargingPlayerPhase charging) {
            charging.setPathTarget(new Vec3d(x, y, z));
        }
    }

    // ------------------------------------------------------------------ attacks

    private static void shoot(ServerWorld w, EnderDragonEntity d, PlayerEntity t) {
        double sx = d.getX();
        double sy = d.getY() + 2;
        double sz = d.getZ();
        Vec3d dir = new Vec3d(t.getX() - sx, t.getBodyY(0.5) - sy, t.getZ() - sz).normalize();
        DragonFireballEntity fb = new DragonFireballEntity(w, d, dir);
        fb.setPosition(sx + dir.x * 8, sy + dir.y * 8, sz + dir.z * 8);
        w.spawnEntity(fb);
    }

    private static void spawnWave(Brain b, PlayerEntity t) {
        ServerWorld w = b.world;
        Random r = w.getRandom();
        Box box = new Box(t.getX() - 80, t.getY() - 40, t.getZ() - 80, t.getX() + 80, t.getY() + 60, t.getZ() + 80);
        int existing = w.getEntitiesByClass(MobEntity.class, box, e -> e.getCommandTags().contains(MINION_TAG)).size();
        int cap = 14 + b.phase * 6;
        int count = Math.min(cap - existing, 3 + b.phase * 2);

        for (int i = 0; i < count; i++) {
            List<EntityType<? extends MobEntity>> pool = b.phase == 1 ? POOL_1 : b.phase == 2 ? POOL_2 : POOL_3;
            EntityType<? extends MobEntity> type = pool.get(r.nextInt(pool.size()));
            MobEntity mob = type.create(w, SpawnReason.EVENT);
            if (mob == null) continue;

            double a = r.nextDouble() * Math.PI * 2;
            double rad = 14 + r.nextDouble() * 10;
            double x = t.getX() + Math.cos(a) * rad;
            double z = t.getZ() + Math.sin(a) * rad;
            double y = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, (int) Math.floor(x), (int) Math.floor(z));
            if (type == EntityType.PHANTOM) y += 14;

            mob.setPosition(x, y, z);
            mob.initialize(w, w.getLocalDifficulty(BlockPos.ofFloored(x, y, z)), SpawnReason.EVENT, null);
            mob.addCommandTag(MINION_TAG);
            mob.setPersistent();
            mob.setTarget(t);
            w.spawnEntity(mob);
        }
    }

    // ------------------------------------------------------------------ pylons (replace End crystals)

    static void spawnPylons(ServerWorld w, double cx, double cz, int n) {
        Random r = w.getRandom();
        double off = r.nextDouble() * Math.PI * 2;
        for (int i = 0; i < n; i++) {
            double a = off + Math.PI * 2 * i / n;
            double rad = 22 + (i % 2) * 10;
            int bx = (int) Math.floor(cx + Math.cos(a) * rad);
            int bz = (int) Math.floor(cz + Math.sin(a) * rad);
            int by = w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, bx, bz);
            EndCrystalEntity c = new EndCrystalEntity(w, bx + 0.5, by, bz + 0.5);
            c.setShowBottom(false);
            c.addCommandTag(PYLON_TAG);
            w.spawnEntity(c);
        }
    }

    private static int countPylons(ServerWorld w, EnderDragonEntity d) {
        Box box = new Box(d.getX() - 200, w.getBottomY(), d.getZ() - 200,
                d.getX() + 200, w.getBottomY() + w.getHeight(), d.getZ() + 200);
        return w.getEntitiesByClass(EndCrystalEntity.class, box, e -> e.getCommandTags().contains(PYLON_TAG)).size();
    }

    // ------------------------------------------------------------------ damage / death

    /** Fabric ALLOW_DAMAGE hook: shield while pylons live, custom death at lethal damage. */
    public static boolean allowDamage(LivingEntity entity, DamageSource source, float amount) {
        if (!(entity instanceof EnderDragonEntity d)) return true;
        Brain b = BRAINS.get(d.getUuid());
        if (b == null || b.defeated || b.world == null) return true;
        if (source.isOf(DamageTypes.GENERIC_KILL)) return true;

        if (b.pylonCount > 0) {
            if (source.getAttacker() instanceof ServerPlayerEntity p && b.hintCooldown-- <= 0) {
                p.sendMessage(Text.literal("The dragon is shielded! Destroy the end crystal pylons first."), true);
                b.hintCooldown = 40;
            }
            return false;
        }

        if (amount >= d.getHealth()) {
            defeat(b, d);
            return false;
        }
        return true;
    }

    private static void defeat(Brain b, EnderDragonEntity d) {
        b.defeated = true;
        ServerWorld w = b.world;
        b.bar.clearPlayers();

        ArmageddonMod.state.defeated = true;
        ArmageddonMod.state.save(w.getServer());

        broadcast(w, "The Armageddon Dragon has fallen! The world is saved... for now.");

        AdvancementEntry adv = w.getServer().getAdvancementLoader().get(Identifier.of(ArmageddonMod.MOD_ID, "survivor"));
        for (ServerPlayerEntity p : w.getPlayers()) {
            double dx = p.getX() - d.getX();
            double dz = p.getZ() - d.getZ();
            if (adv != null && dx * dx + dz * dz < 300.0 * 300.0) {
                p.getAdvancementTracker().grantCriterion(adv, "done");
            }
            Box box = new Box(p.getX() - 120, p.getY() - 80, p.getZ() - 120, p.getX() + 120, p.getY() + 120, p.getZ() + 120);
            for (MobEntity m : w.getEntitiesByClass(MobEntity.class, box, e -> e.getCommandTags().contains(MINION_TAG))) {
                m.discard();
            }
            for (EndCrystalEntity c : w.getEntitiesByClass(EndCrystalEntity.class, box, e -> e.getCommandTags().contains(PYLON_TAG))) {
                c.discard();
            }
        }

        w.spawnEntity(new ItemEntity(w, d.getX(), d.getY(), d.getZ(), new ItemStack(Items.DRAGON_EGG)));

        // vanilla death animation, right where it flies
        d.setHealth(0.0F);
    }

    // ------------------------------------------------------------------ helpers

    private static void updateBar(Brain b, EnderDragonEntity d) {
        float pct = Math.max(0f, Math.min(1f, d.getHealth() / d.getMaxHealth()));
        b.bar.setPercent(pct);
        if (b.pylonCount > 0) {
            b.bar.setName(Text.literal("Armageddon Dragon - SHIELDED (" + b.pylonCount + " pylons)"));
            b.bar.setColor(BossBar.Color.BLUE);
        } else {
            b.bar.setName(Text.literal("Armageddon Dragon - Phase " + b.phase));
            b.bar.setColor(BossBar.Color.PURPLE);
        }
        if (d.age % 20 == 0) {
            for (ServerPlayerEntity p : b.world.getPlayers()) {
                double dx = p.getX() - d.getX();
                double dz = p.getZ() - d.getZ();
                if (dx * dx + dz * dz < 300.0 * 300.0) b.bar.addPlayer(p);
                else b.bar.removePlayer(p);
            }
        }
    }

    private static void broadcast(ServerWorld w, String msg) {
        w.getServer().getPlayerManager().broadcast(Text.literal(msg), false);
    }
}
